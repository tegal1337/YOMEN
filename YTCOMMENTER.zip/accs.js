module.exports = {
data: [
        {
        keywords: ["keyword1", "tegal1337"],
        comments: ["hello","let's be a friend","subs to subs ahaha"],
        usernamegoogle: "username",
        passwordgoogle: "pass",
        delaycomment: 60, // delay ( per second )
        trending: false,
        copycomment:true, // false if you want use comment above , i mean from array
        userdatadir : "username"
    }, {
        keywords: ["keyword1", "tegal1337"],
        comments: ["hello","let's be a friend","subs to subs ahaha"],
        usernamegoogle: "username",
        passwordgoogle: "pass",
        delaycomment: 60, // delay ( per second )
        trending: false,
        copycomment:true, // false if you want use comment above , i mean from array
        userdatadir : "username"
    }, {
        keywords: ["keyword1", "tegal1337"],
        comments: ["hello","let's be a friend","subs to subs ahaha"],
        usernamegoogle: "username",
        passwordgoogle: "pass",
        delaycomment: 60, // delay ( per second )
        trending: false,
        copycomment:true, // false if you want use comment above , i mean from array
        userdatadir : "username"
    }, 
]
};
