module.exports = {

    chromepath : require("./src/chromepathfinder"),
    subsribe : require("./src/subscribeChannel"),
    copycommnet : require("./src/copyComment"),
    autoscroll : require("./src/autoScroll"),
    manualComment : require("./src/manualComment"),
    closePage : require("./src/closePage"),
    likeVideos : require("./src/likeVideos"),
    quoteComment : require("./src/quoteIndo"),
}