module.exports = {
    closePage: async (pages) => {
         await pages.close();
}
}