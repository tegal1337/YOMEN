module.exports = {
  keywords: ["shorts", "pass"],
  comments: ["hello","let's be a friend","subs to subs ahaha"],
  usernamegoogle: "usernamegoogle",
  passwordgoogle: "passwordgoogle",
  delaycomment: 60, // delay ( per second )
  trending: true,
  copycomment:true, // false if you want use comment above , i mean from array
  userdatadir : "fdciabdul"
};
